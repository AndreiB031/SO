// SPDX-License-Identifier: BSD-3-Clause

#include <aio.h>
#include <arpa/inet.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <libaio.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <sys/sendfile.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "aws.h"
#include "utils/debug.h"
#include "utils/sock_util.h"
#include "utils/util.h"
#include "utils/w_epoll.h"


io_context_t ctx;
static int listenfd;
static int epollfd;

static int aws_on_path_cb(http_parser *p, const char *buf, size_t len)
{
	struct connection *conn;

	conn = (struct connection *)p->data;
	memcpy(conn->request_path, buf, len);
	conn->have_path = 1;
	conn->request_path[len] = '\0';
	return 0;
}

static void connection_prepare_send_reply_header(struct connection *conn)
{
	const char *header_format = "HTTP/1.1 200 OK\r\nServer: Apache/2.2.9\r\nAccept-Ranges: bytes\r\nContent-Length: "
								"%ld\r\nVary: Accept-Encoding\r\nConnection: close\r\nContent-Type: text/html\r\n\r\n";

	conn->send_len = snprintf(conn->send_buffer, sizeof(conn->send_buffer), header_format, conn->file_size);
}

static void connection_prepare_send_404(struct connection *conn)
{
	ssize_t sent_num = 1;
	const char *error = "HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\n"
						"Connection: close\r\n\r\n<html><body><h1>404 Not Found</h1></body></html>\n";

	while (sent_num > 0)
		sent_num = send(conn->sockfd, error, strlen(error), 0);

	if (sent_num <= 0) {
		perror("send");
		connection_remove(conn);
	}
}

static enum resource_type connection_get_resource_type(struct connection *conn)
{
	if (!strncmp(conn->request_path, "/dynamic/", 9))
		return conn->res_type = RESOURCE_TYPE_DYNAMIC;
	if (!strncmp(conn->request_path, "/static/", 8))
		return conn->res_type = RESOURCE_TYPE_STATIC;
	return RESOURCE_TYPE_NONE;
}

struct connection *connection_create(int sockfd)
{
	struct connection *connection;

	connection = calloc(1, sizeof(struct connection));
	connection->sockfd = sockfd;
	connection->state = STATE_INITIAL;
	connection->fd = -1;
	connection->eventfd = eventfd(0, EFD_NONBLOCK);
	connection->recv_buffer[0] = '\0';
	connection->send_buffer[0] = '\0';
	return connection;
	return NULL;
}

void connection_start_async_io(struct connection *conn)
{
	*(conn->piocb) = &conn->iocb;
	io_prep_pread(*conn->piocb, conn->fd, conn->send_buffer, sizeof(conn->send_buffer), conn->file_pos);
	w_epoll_update_ptr_in(epollfd, conn->sockfd, conn);
	io_set_eventfd(&conn->iocb, conn->eventfd);
	w_epoll_add_ptr_in(epollfd, conn->eventfd, conn);
	if (io_submit(ctx, 1, conn->piocb) == 1) {
		conn->ctx = ctx;
		return;
	}
	perror("io_submit");
	io_destroy(ctx);
}

void connection_remove(struct connection *conn)
{
	if (conn) {
		if (-1 != conn->sockfd) {
			close(conn->sockfd);
			conn->sockfd = -1;
		}
		if (-1 != conn->fd) {
			close(conn->fd);
			conn->fd = -1;
		}
		free(conn);
	}
	dlog(LOG_INFO, "Connection removed\n");
}
void handle_new_connection(void)
{
	int client = accept(listenfd, NULL, NULL);

	if (-1 == client) {
		perror("accept");
	} else {
		int flags;

		flags = fcntl(client, F_GETFL, 0);
		if (-1 == flags || -1 == fcntl(client, F_SETFL, flags | O_NONBLOCK)) {
			perror("fcntl");
			exit(EXIT_FAILURE);
		}
		struct connection *conn = connection_create(client);

		w_epoll_add_ptr_in(epollfd, conn->sockfd, conn);
	}
}
void receive_data(struct connection *conn)
{
	ssize_t bts = 1;
	char *buff = malloc(BUFSIZ * sizeof(char));

	while (bts > 0) {
		bts = recv(conn->sockfd, buff, BUFSIZ, 0);
		conn->recv_len = conn->recv_len + bts;
		strcat(conn->recv_buffer, buff);
	}
	if (-1 == parse_header(conn) || -1 == connection_open_file(conn))
		conn->state = STATE_SENDING_404;
	else
		conn->state = STATE_REQUEST_RECEIVED;
}
int connection_open_file(struct connection *conn)
{
	int fd;

	fd = open(conn->filename, O_RDONLY);
	if (fd < 0) {
		perror("open");
		return -1;
	}
	struct stat st;

	if (-1 == fstat(fd, &st)) {
		perror("fstat");
		close(fd);
		return -1;
	}
	conn->file_pos = 0;
	conn->file_size = st.st_size;
	conn->fd = fd;
	return 0;
}
void connection_complete_async_io(struct connection *conn)
{
	struct io_event *event_list;
	int event_n;

	event_list = malloc(10 * sizeof(struct io_event));
	event_n = io_getevents(conn->ctx, 1, 1, event_list, NULL);

	dlog(LOG_INFO, "Num events: %d\n", event_n);
	if (event_n == -1) {
		perror("io_getevents");
	} else {
		ssize_t bytes = event_list[0].res;

		if (bytes >= 0) {
			conn->send_pos = 0;
			conn->send_len = bytes;
			conn->file_pos = conn->file_pos + bytes;
			w_epoll_update_ptr_out(epollfd, conn->sockfd, conn);
			w_epoll_remove_ptr(epollfd, conn->eventfd, conn);
			conn->state = STATE_DYNAMIC;
		} else {
			perror("io_getevents");
		}
	}
}

int parse_header(struct connection *conn)
{
	http_parser local_parser;

	http_parser_init(&local_parser, HTTP_REQUEST);
	http_parser_settings settings_on_path = {.on_message_begin = 0,
											 .on_header_field = 0,
											 .on_header_value = 0,
											 .on_path = aws_on_path_cb,
											 .on_url = 0,
											 .on_fragment = 0,
											 .on_query_string = 0,
											 .on_body = 0,
											 .on_headers_complete = 0,
											 .on_message_complete = 0};
	local_parser.data = conn;
	http_parser_execute(&local_parser, &settings_on_path, conn->recv_buffer, conn->recv_len);

	if (!conn->have_path)
		return 1;

	if (connection_get_resource_type(conn) == RESOURCE_TYPE_STATIC ||
	connection_get_resource_type(conn) == RESOURCE_TYPE_DYNAMIC) {
		snprintf(conn->filename, BUFSIZ, "%s%s", AWS_DOCUMENT_ROOT, conn->request_path + 1);
	} else {
		connection_prepare_send_404(conn);
		return -1;
	}
	return 1;
}

enum connection_state connection_send_static(struct connection *conn)
{
	off_t off;
	int sent_byte;

	off = conn->file_pos;
	sent_byte = sendfile(conn->sockfd, conn->fd, &off, conn->file_size - conn->file_pos);
	if (sent_byte > 0) {
		conn->file_pos = conn->file_pos + sent_byte;
		if (conn->file_pos != conn->file_size) {
			conn->state = STATE_SENDING_DATA;
			return STATE_SENDING_DATA;
		}
		conn->state = STATE_DATA_SENT;
		return STATE_DATA_SENT;
	}
	if (EAGAIN != errno && EWOULDBLOCK != errno) {
		perror("sendfile");
		conn->state = STATE_SENDING_404;
	}
	return STATE_SENDING_404;
}

int connection_send_data(struct connection *conn)
{
	int total_sent_bytes = 0;
	int sent_byte = 0;

	while (conn->send_pos < conn->send_len) {
		sent_byte = send(conn->sockfd, conn->send_buffer + conn->send_pos, conn->send_len - conn->send_pos, 0);
		conn->send_pos = conn->send_pos + sent_byte;
		total_sent_bytes = total_sent_bytes + sent_byte;
	}
	return total_sent_bytes;
}

void handle_input(struct connection *conn)
{
	if (conn->state == STATE_ASYNC_ONGOING) {
		connection_complete_async_io(conn);
	} else {
		if (conn->state == STATE_INITIAL) {
			conn->state = STATE_RECEIVING_DATA;
			receive_data(conn);
			w_epoll_update_ptr_out(epollfd, conn->sockfd, conn);
		}
	}
}

void handle_output(struct connection *conn)
{
	if (conn->state == STATE_ASYNC_ONGOING)
		connection_start_async_io(conn);

	if (conn->state == STATE_SENDING_DATA) {
		if (conn->res_type == RESOURCE_TYPE_DYNAMIC) {
			conn->state = STATE_ASYNC_ONGOING;
			connection_start_async_io(conn);
		} else {
			if (conn->res_type == RESOURCE_TYPE_STATIC)
				conn->state = connection_send_static(conn);
			else
				conn->state = STATE_SENDING_404;
		}
	}
	if (conn->state == STATE_SENDING_HEADER) {
		connection_send_data(conn);
		conn->state = STATE_HEADER_SENT;
	}
	if (conn->state == STATE_HEADER_SENT) {
		if (RESOURCE_TYPE_STATIC == conn->res_type || RESOURCE_TYPE_DYNAMIC == conn->res_type)
			conn->state = STATE_SENDING_DATA;
		else
			conn->state = STATE_SENDING_404;
	}

	if (conn->state == STATE_SENDING_404) {
		connection_prepare_send_404(conn);
		conn->state = STATE_404_SENT;
	}
	if (conn->state == STATE_404_SENT)
		connection_remove(conn);

	if (conn->state == STATE_DYNAMIC) {
		connection_send_data(conn);
		if (conn->file_size != conn->file_pos)
			conn->state = STATE_SENDING_DATA;
		else
			conn->state = STATE_DATA_SENT;
	}
	if (conn->state == STATE_REQUEST_RECEIVED) {
		connection_prepare_send_reply_header(conn);
		conn->state = STATE_SENDING_HEADER;
	}
	if (conn->state == STATE_DATA_SENT)
		connection_remove(conn);
}

void handle_client(uint32_t events, struct connection *conn)
{
	if (EPOLLIN & events)
		handle_input(conn);

	if (EPOLLOUT & events)
		handle_output(conn);

	if (EPOLLHUP & events || EPOLLERR & events)
		connection_remove(conn);
}

int main(void)
{
	epollfd = w_epoll_create();
	if (epollfd < 0) {
		perror("w_epoll_create");
		return -1;
	}

	if (io_setup(1, &ctx)) {
		perror("io_setup");
		return -1;
	}

	listenfd = tcp_create_listener(AWS_LISTEN_PORT, DEFAULT_LISTEN_BACKLOG);
	if (listenfd < 0) {
		perror("tcp_create_listener");
		return -1;
	}
	int rc;

	rc = w_epoll_add_fd_in(epollfd, listenfd);
	if (rc < 0) {
		perror("w_epoll_add_fd_in");
		return -1;
	}

	while (1337) {
		struct epoll_event rev;
		int ret;

		ret = epoll_wait(epollfd, &rev, 1, -1);
		if (ret < 0) {
			perror("w_epoll_wait");
			return -1;
		}
		if (rev.data.fd == listenfd) {
			handle_new_connection();
		} else {
			struct connection *conn = (struct connection *)rev.data.ptr;

			handle_client(rev.events, conn);
		}
	}
	return 0;
}
