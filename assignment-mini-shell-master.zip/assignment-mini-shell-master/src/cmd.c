// SPDX-License-Identifier: BSD-3-Clause

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "cmd.h"
#include "utils.h"

#define READ		0
#define WRITE		1

typedef struct {
	int read;
	int write;
} Fd_struct;

/**
 * Internal change-directory command.
 */
static bool shell_cd(word_t *dir)
{
	return (dir && dir->string && !chdir(dir->string));
}

/**
 * Internal exit/quit command.
 */
static int shell_exit(void)
{
	exit(0);
}

/**
 * Parse a simple command (internal, environment variable assignment,
 * external command).
 */
static int parse_simple(simple_command_t *s, int level, command_t *father)
{
	if (!s)
		return 0;

	char *cwd = malloc(1024 * sizeof(char));

	if (!getcwd(cwd, (1024 * sizeof(char)))) {
		free(cwd);
		return 0;
	}

	bool cd_check = false;

	if (!strcmp("cd", s->verb->string)) {
		if (!s->params || s->params->next_part) {
			free(cwd);
			return 0;
		}

		cd_check = true;
		int in_cpy = dup(STDIN_FILENO);
		int out_cpy = dup(STDOUT_FILENO);

		if (s->out) {
			char *out = malloc(1024 * sizeof(char));

			snprintf(out, 1024 * sizeof(char), "%s/%s", cwd, s->out->string);
			if (s->out->next_part)
				strcat(out, get_word(s->out->next_part));

			int fd = open(out, O_WRONLY | O_CREAT | O_TRUNC, 0644);

			free(out);
			dup2(fd, STDOUT_FILENO);
			close(fd);
		}

		if (s->in) {
			char *in = malloc(1024 * sizeof(char));

			snprintf(in, 1024 * sizeof(char), "%s/%s", cwd, s->in->string);
			int fd = open(in, O_RDONLY);

			free(in);
			dup2(fd, STDIN_FILENO);
			close(fd);
		}

		dup2(in_cpy, STDIN_FILENO);
		close(in_cpy);
		dup2(out_cpy, STDOUT_FILENO);
		close(out_cpy);
		free(cwd);
		return shell_cd(s->params);
	}

	if (!strcmp(s->verb->string, "exit") || !strcmp(s->verb->string, "quit")) {
		free(cwd);
		return shell_exit();
	}

	if (s->verb->next_part) {
		char *value = get_word(s->verb->next_part->next_part);

		setenv(s->verb->string, value, 1);
		free(value);
		free(cwd);
		return 1;
	}

	pid_t pid = fork();

	if (pid) {
		int status;

		free(cwd);
		waitpid(pid, &status, 0);
		return !WEXITSTATUS(status);
	}
	int in_cpy = dup(STDIN_FILENO);
	int out_cpy = dup(STDOUT_FILENO);
	int err_cpy = dup(STDERR_FILENO);

	if (s->out && !s->err) {
		char *out = malloc(1024 * sizeof(char));

		if (cd_check)
			snprintf(out, 1024 * sizeof(char), "%s/%s", cwd, s->out->string);
		else
			snprintf(out, 1024 * sizeof(char), "%s", s->out->string);

		if (s->out->next_part)
			strcat(out, get_word(s->out->next_part));

		int fd;

		if (s->io_flags == IO_REGULAR)
			fd = open(out, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		if (s->io_flags == IO_OUT_APPEND)
			fd = open(out, O_WRONLY | O_CREAT | O_APPEND, 0644);

		free(out);
		dup2(fd, STDOUT_FILENO);
		close(fd);
	}

	if (s->err && !s->out) {
		char *err = malloc(1024 * sizeof(char));

		if (cd_check)
			snprintf(err, 1024 * sizeof(char), "%s/%s", cwd, s->err->string);
		else
			snprintf(err, 1024 * sizeof(char), "%s", s->err->string);

		if (s->err->next_part)
			strcat(err, get_word(s->err->next_part));

		int fd;

		if (s->io_flags == IO_REGULAR)
			fd = open(err, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		if (s->io_flags == IO_ERR_APPEND)
			fd = open(err, O_WRONLY | O_CREAT | O_APPEND, 0644);

		free(err);
		dup2(fd, STDERR_FILENO);
		close(fd);
	}

	if (s->out && s->err) {
		char *out = malloc(1024 * sizeof(char));
		char *err = malloc(1024 * sizeof(char));

		if (cd_check) {
			snprintf(out, 1024 * sizeof(char), "%s/%s", cwd, s->out->string);
			snprintf(err, 1024 * sizeof(char), "%s/%s", cwd, s->err->string);
		} else {
			snprintf(out, 1024 * sizeof(char), "%s", s->out->string);
			snprintf(err, 1024 * sizeof(char), "%s", s->err->string);
		}

		if (s->out->next_part)
			strcat(out, get_word(s->out->next_part));

		if (s->err->next_part)
			strcat(err, get_word(s->err->next_part));

		int out_fd = open(out, O_WRONLY | O_CREAT | O_APPEND, 0644);

		free(out);
		dup2(out_fd, STDOUT_FILENO);
		close(out_fd);

		int err_fd = open(err, O_WRONLY | O_CREAT | O_TRUNC, 0644);

		free(err);
		dup2(err_fd, STDERR_FILENO);
		close(err_fd);
	}

	if (s->in) {
		char *in = malloc(1024 * sizeof(char));

		if (cd_check)
			snprintf(in, 1024 * sizeof(char), "%s/%s", cwd, s->in->string);
		else
			snprintf(in, 1024 * sizeof(char), "%s", s->in->string);

		if (s->in->next_part)
			strcat(in, get_word(s->in->next_part));

		int fd = open(in, O_RDONLY);

		free(in);
		dup2(fd, STDIN_FILENO);
		close(fd);
	}

	int argc;
	char **argv = get_argv(s, &argc);

	if (execvp(argv[0], argv) == -1) {
		printf("Execution failed for '%s'\n", argv[0]);
		exit(1);
	}

	free(cwd);
	dup2(in_cpy, STDIN_FILENO);
	close(in_cpy);
	dup2(out_cpy, STDOUT_FILENO);
	close(out_cpy);
	dup2(err_cpy, STDERR_FILENO);
	close(err_cpy);
	return 0;
}

/**
 * Process two commands in parallel, by creating two children.
 */
static bool run_in_parallel(command_t *cmd1, command_t *cmd2, int level,
		command_t *father)
{
	pid_t pid1 = fork();

	if (!pid1)
		exit(parse_command(cmd1, level + 1, father));

	pid_t pid2 = fork();

	if (!pid2)
		exit(parse_command(cmd2, level + 1, father));

	int stat1, stat2;

	waitpid(pid1, &stat1, 0);
	waitpid(pid2, &stat2, 0);

	return (WIFEXITED(stat1) && WIFEXITED(stat2));
}

/**
 * Run commands by creating an anonymous pipe (cmd1 | cmd2).
 */
static bool run_on_pipe(command_t *cmd1, command_t *cmd2, int level,
		command_t *father)
{
	int in_cpy = dup(STDIN_FILENO);
	int out_cpy = dup(STDOUT_FILENO);
	int err_cpy = dup(STDERR_FILENO);
	Fd_struct *fd = malloc(sizeof(Fd_struct));

	pipe((int *)fd);
	pid_t pid1 = fork();

	if (!pid1) {
		close(fd->read);
		dup2(fd->write, STDOUT_FILENO);
		close(fd->write);
		exit(parse_command(cmd1, level + 1, father));
	}

	pid_t pid2 = fork();

	if (!pid2) {
		close(fd->write);
		dup2(fd->read, STDIN_FILENO);
		close(fd->read);
		exit(parse_command(cmd2, level + 1, father));
	}

	close(fd->read);
	close(fd->write);
	free(fd);
	int stat1;

	waitpid(pid1, &stat1, 0);
	int stat2;

	waitpid(pid2, &stat2, 0);

	dup2(in_cpy, STDIN_FILENO);
	close(in_cpy);
	dup2(out_cpy, STDOUT_FILENO);
	close(out_cpy);
	dup2(err_cpy, STDERR_FILENO);
	close(err_cpy);

	return WEXITSTATUS(stat2);
}

/**
 * Parse and execute a command.
 */
int parse_command(command_t *c, int level, command_t *father)
{
	if (!c)
		return false;

	int check;

	switch (c->op) {
	case OP_NONE:
		return parse_simple(c->scmd, level + 1, c);

	case OP_SEQUENTIAL:
		parse_command(c->cmd1, level, c);
		parse_command(c->cmd2, level, c);
		return 1;

	case OP_PARALLEL:
		return run_in_parallel(c->cmd1, c->cmd2, level, c);

	case OP_CONDITIONAL_NZERO:
		check = parse_command(c->cmd1, level, c);
		if (!check)
			return parse_command(c->cmd2, level, c);
		return check;

	case OP_CONDITIONAL_ZERO:
		check = parse_command(c->cmd1, level, c);
		if (check)
			return parse_command(c->cmd2, level, c);
		return check;

	case OP_PIPE:
		return run_on_pipe(c->cmd1, c->cmd2, level, c);

	default:
		return SHELL_EXIT;
	}
}
