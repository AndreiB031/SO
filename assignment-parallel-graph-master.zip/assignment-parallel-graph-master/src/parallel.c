// SPDX-License-Identifier: BSD-3-Clause

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>

#include "os_graph.h"
#include "os_threadpool.h"
#include "log/log.h"
#include "utils.h"

#define NUM_THREADS		4

static int sum;
static os_graph_t *graph;
static os_threadpool_t *threadp;

/* TODO: Define graph synchronization mechanisms. */

static pthread_mutex_t sum_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t graph_mutex = PTHREAD_MUTEX_INITIALIZER;

/* TODO: Define graph task argument. */

static os_task_t **tasks;
struct graph_task_arg {
	unsigned int node_idx;
};

static struct graph_task_arg *init_task_arg(unsigned int local_node_idx)
{
	struct graph_task_arg *arg = malloc(sizeof(struct graph_task_arg));

	DIE(arg == NULL, "malloc not mallocking");
	arg->node_idx = local_node_idx;
	return arg;
}

static void process_node(unsigned int idx)
{
	/* TODO: Implement thread-pool based processing of graph. */

	os_node_t *node;

	pthread_mutex_lock(&graph_mutex);
	node = graph->nodes[idx];
	pthread_mutex_unlock(&graph_mutex);

	pthread_mutex_lock(&sum_mutex);
	sum += node->info;
	pthread_mutex_unlock(&sum_mutex);

	pthread_mutex_lock(&graph_mutex);
	for (unsigned int i = 0; i < node->num_neighbours; i++) {
		unsigned int neighbor_idx = node->neighbours[i];

		if (graph->visited[neighbor_idx] == NOT_VISITED) {
			/* Enqueue a task for each unvisited neighbor */
			graph->visited[neighbor_idx] = PROCESSING;
			enqueue_task(threadp, tasks[neighbor_idx]);
		}
	}
	graph->visited[idx] = DONE;
	pthread_mutex_unlock(&graph_mutex);
}

/* Task Execution Function */
static void graph_task(void *arg)
{
	struct graph_task_arg *task_arg = (struct graph_task_arg *)arg;

	process_node(task_arg->node_idx);
}

/* Initialize Tasks for Thread Pool */
static void initialize_tasks(unsigned int num_nodes)
{
	tasks = malloc(num_nodes * sizeof(os_task_t *));
	DIE(tasks == NULL, "malloc not mallocking");

	for (unsigned int i = 0; i < num_nodes; i++) {
		struct graph_task_arg *task_arg = init_task_arg(i);

		tasks[i] = create_task(graph_task, task_arg, free);
	}
}

FILE *read_file(char *arg)
{
	FILE *input_file;

	input_file = fopen(arg, "r");
	DIE(input_file == NULL, "fopen not fopening");
	return input_file;
}

int main(int argc, char *argv[])
{
	if (argc != 2) {
		fprintf(stderr, "Usage: %s input_file\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	graph = create_graph_from_file(read_file(argv[1]));

	/* TODO: Initialize graph synchronization mechanisms. */

	pthread_mutex_init(&sum_mutex, NULL);
	pthread_mutex_init(&graph_mutex, NULL);

	threadp = create_threadpool(NUM_THREADS);

	/* Initialize tasks for each node in the graph */
	initialize_tasks(graph->num_nodes);

	process_node(0);
	wait_for_completion(threadp);
	destroy_threadpool(threadp);

	printf("%d", sum);

	return 0;
}
