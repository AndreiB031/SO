// SPDX-License-Identifier: BSD-3-Clause

#include "osmem.h"

void *os_malloc(size_t size)
{
	/* TODO: Implement os_malloc */
	return NULL;
}

void os_free(void *ptr)
{
	/* TODO: Implement os_free */
}

void *os_calloc(size_t nmemb, size_t size)
{
	/* TODO: Implement os_calloc */
	return NULL;
}

void *os_realloc(void *ptr, size_t size)
{
	/* TODO: Implement os_realloc */
	return NULL;
}
